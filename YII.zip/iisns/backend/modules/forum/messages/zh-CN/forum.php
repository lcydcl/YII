<?php
return [
	'Forum' => '论坛',
    'Board' => '版块',
	'Thread' => '帖子',
	'Post' => '评论',
];
