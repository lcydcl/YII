<?php
return [
    'adminEmail' => 'admin@examplge.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
];