Contributing to iiSNS
====================

- [Report an issue](docs/internals/report-an-issue.md)
- [Translate documentation or messages](docs/internals/translation-workflow.md)
- [Give us feedback or start a design discussion](http://www.iisns.com/forum/iisns)
- [Contribute to the core code or fix bugs](docs/internals/git-workflow.md)
